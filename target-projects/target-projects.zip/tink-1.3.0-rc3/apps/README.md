This folder contains applications that depend on or extend Tink's functionality.
